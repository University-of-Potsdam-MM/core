15.02.2012

Following new icons have been added:
core/img/filetypes/application-vnd.oasis.opendocument.formula.png
core/img/filetypes/application-vnd.oasis.opendocument.graphics.png
core/img/filetypes/application-vnd.oasis.opendocument.presentation.png
core/img/filetypes/application-vnd.oasis.opendocument.spreadsheet.png
core/img/filetypes/application-vnd.oasis.opendocument.text.png
	Download: http://odftoolkit.org/ODF-Icons#ODF_Icons
	License: Apache 2.0
	
core/img/filetypes/application-x-7z-compressed.png
core/img/filetypes/application-x-bzip-compressed-tar.png
core/img/filetypes/application-x-bzip.png
core/img/filetypes/application-x-compressed-tar.png
core/img/filetypes/application-x-deb.png
core/img/filetypes/application-x-debian-package.png
core/img/filetypes/application-x-gzip.png
core/img/filetypes/application-x-lzma-compressed-tar.png
core/img/filetypes/application-x-rar.png
core/img/filetypes/application-x-rpm.png
core/img/filetypes/application-x-tar.png
core/img/filetypes/application-x-tarz.png
core/img/filetypes/application-zip.png
	Author: Gomez Hyuuga
	License: Creative Commons Attribution-Share Alike 3.0 Unported License	
	Download: http://kde-look.org/content/show.php/?content=101767

