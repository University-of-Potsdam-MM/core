<ul>
	<li class='update'>
		<?php p($l->t('Updating ownCloud to version %s, this may take a while.',
			array($_['version']))); ?><br /><br />
	</li>
</ul>
